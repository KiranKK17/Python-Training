x=float(input("Enter the number:"))
print(round(x,2))
