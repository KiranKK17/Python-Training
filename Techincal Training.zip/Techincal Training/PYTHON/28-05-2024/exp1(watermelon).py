w = int(input("Enter the weight of watermelon:"))
if w > 4:           # > is used for comparsion operator which checks whether the left side value is less or greater than the right side value
    print("YES")
elif  w % 2 == 0:   # % is used for getting the reminder of the function
    print("YES")
else:
    print("NO")
