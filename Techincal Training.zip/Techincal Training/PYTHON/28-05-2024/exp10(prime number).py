a=int(input("Enter the value:"))
count=0
for i in range(1,8,1):
    if(a%i==0):
        count=count+1
if(count==2):
        print("prime number")
else:
        print("not an prime number")
    
