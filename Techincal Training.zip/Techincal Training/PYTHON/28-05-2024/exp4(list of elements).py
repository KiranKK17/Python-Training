n=int(input("Enter the value:"))
n=list(int(input().split("#")))
print()
