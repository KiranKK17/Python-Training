year=0
while(limak<bob):
    bob*=2
    limak*=3
    year+=1
print(year)
