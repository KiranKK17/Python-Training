#NESTED DICTIONARY
d={1:'hi','a':123,100:{2:'abc','x':452}}
print(d[100]['x'])


