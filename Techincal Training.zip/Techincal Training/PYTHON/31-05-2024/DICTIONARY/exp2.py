d={1:'hi', 'a':123, 100:32.4}
#adding an element to dictionary
d[1]=1000
print(d)
#delete a dictionary
del(d)
print(d)
