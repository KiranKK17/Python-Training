#SET BUILT-IN FUNCTIONS
s={1,0,3,4,5,2,7,6,8,9}
print(sum(s))
print(max(s))
print(min(s))
print(all(s))
print(any(s))
print(sorted(s))
