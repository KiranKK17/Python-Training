set1={10,20,30,40,50}
set2={60,70,10,30,40,80,20,50}
print(set1.issubset(set2))
print(set2.issuperset(set1))
