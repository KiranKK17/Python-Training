#OPERATIONS ON SET
a={1,2,3,4,5}
b={6,7,8,9,10}
print(1 in a)
print(8 not in b)
print(a==b)
print(a!=b)
