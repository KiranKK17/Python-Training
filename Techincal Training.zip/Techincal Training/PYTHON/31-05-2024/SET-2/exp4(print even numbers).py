start = 1
end = 20
even_numbers = {num for num in range(start, end + 1) if num % 2 == 0}
print("Even numbers:", even_numbers)
