#Creating object using __init__method
class Person:
    def __init__(my,name):  #constructor
        my.name=name
    def say_hi(my):    #method
        print('Hello, my name is',my.name)

p=Person('ammu  ') #object
p.say_hi()   #accessing method
