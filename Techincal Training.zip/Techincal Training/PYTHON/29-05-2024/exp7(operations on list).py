#concatenation of list(+)
L=[1,2,3]
L1=[4,5,6]
print(L+L1)

#reputation of list(*)
L=[1,2,3]
L1=[4,5,6]
print(L*L1)

