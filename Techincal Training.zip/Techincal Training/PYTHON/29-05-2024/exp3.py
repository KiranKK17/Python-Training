L=int(input("Enter the value:"))
R=int(input("Enter the value:"))
x=0
for i in range(L,R+1):
    x=x^i
    print(x)
