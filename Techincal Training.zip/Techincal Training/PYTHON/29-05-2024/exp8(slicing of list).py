L=[10,11,12,13,14,15,16]
print(L[:])
print(L[2:])
print(L[:5])
print(L[2:6])
print(L[-4:-2])
print(L[0:5])
print(L[::2])
print(L[::-1])
print(L[1:6:3])



