"""n1=['Python', 'Flask', 'Django', 'Tkinter']
n2=n1
n3=n2[:2]

n2[0]='Spicy'
n3[1]='Numpy'

s=10
for i in (n1,n2,n3):
    if i[0] == 'Python':
        s += 1
    if i[1] == 'Python':
        s += 2
print(n1)
print(n2)
print(n3)
"""

correct_password = "hello_namste"
attempts = 0
max_attempts = 3

while attempts < max_attempts:
    inputp = input("Enter your password: ")
    if inputp == correct_password:
        print("Correct password")
        break
    else:
        attempts += 1
        print("Incorrect password. You have", max_attempts - attempts, "attempt(s) left.")

# If the user fails to enter the correct password within the maximum attempts
if attempts == max_attempts:
    print("Locked")

