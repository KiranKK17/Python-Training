N=int(input("Enter the value:"))
if(N % 4 == 1):
    print(1)
if(N % 4 == 2):
    print(N + 1)
if(N % 4 == 3):
    print(0)
if(N % 4 == 0):
    print(N)


