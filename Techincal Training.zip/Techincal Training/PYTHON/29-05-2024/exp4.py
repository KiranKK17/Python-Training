L=[12,14,28,'Raghupathi','Sravya Geervani','Swaroopa Rani',1]
L[0]=4
L[1]='Babbulu'
L[2]=12
L[3]='Raghupathi'
L[4]=14
L[5]='Sravya Geervani'
L[6]=28
L.append('Swaroopa Rani')
L.reverse()
print(L)
