L=[1,2,3,4,5]
L1=['a','hi',4512]
L.append(L1)
print(len(L))
L.extend(L1)
print(len(L))
