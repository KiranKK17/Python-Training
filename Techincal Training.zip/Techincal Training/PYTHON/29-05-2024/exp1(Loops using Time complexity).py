n=int(input("Enter the value:"))
x=0
for i in range (1,n+1):
    x=x^i
    print(x)
