#Tuples inside another tuple is nested tuple.

T=(1,2,3,[4,5],('hi','sravya'),10)
print(T)
print(T[3])
print(T[3][0])

L=[4,5,6,(3,4,6),[6,3,8],('hi'),1]
print(L)
