#Write a python program to find the repeated items of a tuple.
t = tuple(input().split(','))
x = {}
for item in t:
    if item in x:
        x[item] += 1
    else:
        x[item] = 1
y = [item for item, count in x.items() if count > 1]
print("y:", y)



my_tuple=(1,2,3,2,4,2,5,2,6)
max_count=max(my_tuple.count(item) for item in my_tuple)
print(f"Maxmimum count:{max_count}")
