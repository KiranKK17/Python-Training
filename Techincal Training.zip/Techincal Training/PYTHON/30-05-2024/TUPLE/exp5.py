#Write a python program to remove an empty tuple(s) from a list of tuples.
a = [(),(),("",),(1,2),(1,2,3),(5)]
b = [t for t in a if t]
print("x:", a)
print("y :",b )
