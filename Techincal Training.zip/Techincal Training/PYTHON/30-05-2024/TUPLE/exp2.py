#Remove an element from an specified index in tuple.
t=tuple(input().split(','))
l=len(t)
print(l)
i=int(input())
t=t[:i]+t[i+i:]
print(t)
