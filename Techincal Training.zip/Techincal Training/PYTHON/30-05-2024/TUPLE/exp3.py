#Write a pyhton program to reverse a tuple
t = tuple(input().split(','))
x = t[::-1]
print("Original tuple:", t)
print("Reversed tuple:", x)
