#SET
set1=set((0,9,0))
set2=set([0,2,9])
set3={}
print(set1,set2,set3)

