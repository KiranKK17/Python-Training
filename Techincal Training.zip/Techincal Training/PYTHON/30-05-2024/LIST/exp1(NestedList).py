#NESTED LIST
L=[12,33.4,'abc',[87,'xyz'],1,[2,68]]
print(L)


L=[1,2,['abc''hi',452],78,100,[124]]
L[5] += [20]
print(L[5])
