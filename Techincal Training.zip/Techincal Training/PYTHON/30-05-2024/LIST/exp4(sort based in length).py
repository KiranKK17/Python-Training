#Input a list and sort the elements in the list based on its length
l = ['hi', '1', '425', '2104']
l.sort(key=len)
print(l)
