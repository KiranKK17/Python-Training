lst=[x ** 2 for x in range(1,11) if x % 2 ==0]
print(lst)


#List Comprehension contains Output Expression , Input Sequence and Variable

L=[1,2,3,4,5,6,7,8,]
L1=[i for i in L if i%2==0]
print(L1)
