#Take 2 diiferent lists , merge them and print a new sorted list.
L1=[1,2,3,6]
L2=[0,5,7]
L1.extend(L2)
L1.sort()
print(L1)
