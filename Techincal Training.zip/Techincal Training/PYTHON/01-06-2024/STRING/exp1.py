#slicing of a string
s='Python'
print(s[:])
print(s[2:])
print(s[:5])
print(s[2:6])
print(s[-4:2])
