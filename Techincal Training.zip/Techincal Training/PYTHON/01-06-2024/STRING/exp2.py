#1
str1="This ia 2020";
str2="2020"
print(str1.isdigit())
print(str2.isdigit())

#2
str1= 'sravya'
print(str1[:9] + 'Coder')
