#Write a python script that takes input from the user and displays that input back in upper and lower cases.
s="my car is bmw"
s1="bmw"
s2=s.replace(s1,s1.upper())
print(s2)
