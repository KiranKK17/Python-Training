# A simple Python function
def fun():
    print("Welcome to GFG")

# Driver code to call a function
fun()

