#Key Argument
def student(firstname, lastname):
    print(firstname, lastname)
student(firstname= 'sravya', lastname='hi')
student(firstname= 'hi', lastname='sravya')
