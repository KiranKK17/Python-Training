#Operators (symbol that performs certain operations)
#1.Arithematic operatiors
a=int(input("enter the number:"))
b=int(input("enter the number:"))
print(a+b)
print(a-b)
print(a*b)
print(a/b) #performs float point arithematic, it always return float type  
print(a%b)
print(a//b) #can perform both floating point and integral arithematic, if argument is in int type the result is int type, but if one argument is float type then result is float type
print(a**b)

#2.Relational operatiors
a=int(input("enter the number:"))
b=int(input("enter the number:"))
a=b
print(a)
print(b)
print(a>b)
print(a<b)
print(a>=b)
print(a<=b)
print(a==b)

#3.Equality operators
a=int(input("enter the number:"))
b=int(input("enter the number:"))
a=b
print(a)
print(b)
print(a==b)
print(a!=b)

#4.Bitwise operator
a=int(input("enter the number:"))
b=int(input("enter the number:"))
a,b=b,a
print(a)
print(b)
print(a&b)
print(a|b)
print(~a)
print(~b)
print(a^b)

#5.Assignment operators (assign value to the variable, to form compound assignment operator then combine assignment operator with some other operators)
a=int(input("enter the number:"))
b=int(input("enter the number:"))
a=a+b
a+=b
a=a-b
a-=b
print(a)
print(b)
