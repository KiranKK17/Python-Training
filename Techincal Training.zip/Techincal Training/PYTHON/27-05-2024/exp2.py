#slicing of string

str1="sravya"
print(str1[3])
print(str1[-3:-1])

#typecasting

a=input("enter the number:")
print(a)
print(type(a))
a=input("enter the name:")
print(a)
print(type(a))
'we can convert any type of value to int & float except complex type'

#immutability

a=10
print(id(a))
a=20
print(id(a))

#list

list1=[4,14,"dog",True,99.9]
list1.append("cat")  #append means adding in end
list1.remove(99.9)
print(list1)
print(list1[2])
print(list1[-5])

#tuple (cant be re added or removed)

tuple1=(4,14,"dog",True,99.9)
print(tuple1)
print(tuple1[2])
print(tuple1[-5])

#set Datatype (order is not important ,duplicates are not allowed , index concept is not acceptable and growable in nature)

set1={4,14,"dog",True,99.9}
set1.add("cat")
print(set1)
set1.remove(99.9)
print(set1)

#dict Datatype (represent a group of values as key value pairs, duplicate keys are not allowed but values can be duplicated, if we try to enter an duplicate key then the old values would be replaced by new values)

d={1:"kiran", 2:"anu"}
print(d[1])

