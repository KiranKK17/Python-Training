aa=20
print(aa)

a=20
print(a)

Aa=20
print(Aa)

__a__=20 #"_ its private, __ its strongly private and __ on both sides its magic words"
print(__a__)

a14=50
print(a14)

a=10
a=20
print(a)

#"true , false and wrong are the words whos frst alphabet should be capital or else it will throw error"

a=20
print(a) # print the value
print(id(a)) #gets the address of object
print(type(a)) #check the type of variable
