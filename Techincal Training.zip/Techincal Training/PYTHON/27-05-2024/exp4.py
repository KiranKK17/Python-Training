year = int(input("Enter a year: "))
def is_leap_year(year):
    if year % 4 == 0:
        return True
    elif year % 1 == 0:
        return False
    else:
        return False
if is_leap_year:
    print("year is a leap year.")
else:
    print("year is not a leap year.")

