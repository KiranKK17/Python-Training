#Generate and print Fibonacci series up to the user-defined range
def fibonacci(n):
    if n <= 1:
        return n
    else:
        return fibonacci(n-1) + fibonacci(n-2)
N = int(input("Enter the number of terms: "))
if N < 3 or N > 50:
    print("Number of terms must be between 3 and 50.")
else:
    for i in range(N):
        print(fibonacci(i), end=" ")