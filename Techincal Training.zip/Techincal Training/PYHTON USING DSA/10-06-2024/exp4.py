#Iterate Over a List of Even Numbers, Increment Each by 2, and Print
for i in[1,2,3,4,5,6,7,8]:
    i=i+2
    print(i)