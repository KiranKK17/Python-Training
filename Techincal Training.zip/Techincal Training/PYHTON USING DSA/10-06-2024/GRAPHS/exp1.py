#Adjacency list in Graph
def print_adj_list(graph):
    print("Adjacency List")
    for node, neighbours in enumerate(graph):
        print(f"{node}: {', '.join(map(str, neighbours))}")

def print_adj_matrix(matrix):
    print("Adjacency Matrix:")
    for row in matrix:
        print(" ".join(map(str, row)))

# Adjacency list
adj_list = [
    [1, 2],  # neighbours of node 0
    [2],     # neighbours of node 1
    [0, 3],  # neighbours of node 2
    [3]      # neighbours of node 3
]

# Define edges based on adjacency list
edges = [
    (0, 1),
    (0, 2),
    (1, 2),
    (2, 0),
    (2, 3),
    (3, 3)
]

# Initialize adjacency matrix
num_nodes = len(adj_list)
adj_matrix = [[0] * num_nodes for _ in range(num_nodes)]

# Populate adjacency matrix
for src, dest in edges:
    adj_matrix[src][dest] = 1

# Print adjacency list
print_adj_list(adj_list)

# Print adjacency matrix
print_adj_matrix(adj_matrix)
