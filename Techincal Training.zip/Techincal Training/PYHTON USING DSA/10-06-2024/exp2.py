#Creating and Printing a List from a Range of Numbers
a=range(2,5)
print(list(a))