#Printing a Slice of a List with Out-of-Bounds Indices
l=[2,3,4,5]
print(l[4:7])