#Iterative List Modification
l=[4,5,6,7,8,9,10]
for i in l:
    l.remove(i)
print(l)